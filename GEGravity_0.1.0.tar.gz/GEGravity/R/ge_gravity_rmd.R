#' @title ge_gravity_rmd
#'
#' Opens Explanatory Rmd Files for GEGravity
#'
#' @description
#'   This is a streamlined way of opening the descriptive logic and testing files
#'   that were made to accompany this function. Specifically, this will copy the appropriate file
#'   and open it with your default rmd application (probably RStudio). This can be done manually
#'   via system.file, i.e. system.file("rmds", "how.Rmd", package = "GEGravity") to get the directory
#'   address of how.Rmd. The system.file approach on its own should be used if you do not want to
#'   exhibit the default behavior.
#'
#' @param file The name of the Rmd file to open. The following are valid parameters:
#' \itemize{
#'  \item "all"     : Opens "about.Rmd"   \cr A compact file with all of the Rmd components combined.
#'  \item "theory"  : Opens "theory.Rmd"  \cr The background, theory, and further readings for how this works.
#'  \item "example" : Opens "example.Rmd" \cr A standard use case of \code{ge_gravity} using \code{TradeData0014}.
#'  \item "logic"   : Opens "logic.Rmd"   \cr A step-by-step of exactly how \code{ge_gravity} operates.
#'  \item "compare" : Opens "compare.Rmd" \cr A comparison of the results of \code{ge_gravity} against its Stata counterpart.
#' }
#'
#' @importFrom utils file.edit
#'
#' @export
ge_gravity_rmd <- function(file = "all"){
  filename <- switch (file,
    "all"     = "how.Rmd",
    "theory"  = "theory.Rmd",
    "example" = "example.Rmd",
    "logic"   = "logic.Rmd",
    "compare" = "compare.Rmd"
  )
  file.copy(system.file("rmds", filename, package = "GEGravity"), ".")
  file.edit(filename)
}

